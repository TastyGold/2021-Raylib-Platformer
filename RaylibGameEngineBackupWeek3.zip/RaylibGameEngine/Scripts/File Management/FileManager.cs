﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace Levels
{
    public static class FileManager
    {
        public const string levelDataPath = "..\\..\\..\\LevelData";

        public static async Task WriteTilemapToFile(Tilemap map, string path)
        {
            int xSize = map.GetTilemapWidth;
            int ySize = map.GetTilemapHeight;

            Console.WriteLine($"Saving file: {path}");
            Console.WriteLine($"Tilemap size: <{xSize}, {ySize}>");

            using (BinaryWriter outputFile = new BinaryWriter(File.Open(Path.Combine(levelDataPath, path), FileMode.Create)))
            {
                //Dimensions
                outputFile.Write((ushort)xSize);
                outputFile.Write((ushort)ySize);

                byte?[,] tiles = map.GetTilemapData();

                //Tiles
                for (int x = 0; x < xSize; x++)
                {
                    for (int y = 0; y < ySize; y++)
                    {
                        outputFile.Write(tiles[x, y].HasValue);
                    }
                }
                for (int x = 0; x < xSize; x++)
                {
                    for (int y = 0; y < ySize; y++)
                    {
                        if (tiles[x, y].HasValue) outputFile.Write((byte)tiles[x, y]);
                    }
                }
            }

            Console.WriteLine($"Finished saving file: {path}");
        }

        public static async Task<byte?[,]> ReadTilemapFromFile(string path)
        {
            Console.WriteLine($"Reading from file: {path}");

            using (BinaryReader binaryFile = new BinaryReader(File.Open(Path.Combine(levelDataPath, path), FileMode.Open)))
            {
                //Dimensions
                ushort xSize = binaryFile.ReadUInt16();
                ushort ySize = binaryFile.ReadUInt16();

                Console.WriteLine($"Tilemap size: <{xSize}, {ySize}>");

                //Tiles
                bool[,] nonAirTiles = new bool[xSize, ySize];

                for (int x = 0; x < xSize; x++)
                {
                    for (int y = 0; y < ySize; y++)
                    {
                        nonAirTiles[x, y] = binaryFile.ReadBoolean();
                    }
                }

                byte?[,] tiles = new byte?[xSize, ySize];

                for (int x = 0; x < xSize; x++)
                {
                    for (int y = 0; y < ySize; y++)
                    {
                        tiles[x, y] = nonAirTiles[x, y] ? binaryFile.ReadByte() : (byte?)null;
                    }
                }

                Console.WriteLine($"Finished reading from file: {path}");
                return tiles;
            }
        }
    }
}