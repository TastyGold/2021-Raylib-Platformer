﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using Engine;

namespace Levels
{
    public class Level
    {
        //Scene control
        private List<Scene> scenes = new List<Scene>();
        private int activeSceneIndex = 0;
        public Scene ActiveScene => scenes[activeSceneIndex];

        public void DrawActiveScene()
        {
            ActiveScene.mainTilemap.DrawAllTiles();
            
            foreach (EntityManagement.Entity e in ActiveScene.GetEntityList)
            {
                e.Draw();
            }
        }


        public void CreateNewScene(Scene newScene)
        {
            scenes.Add(newScene);
        }

        public void LoadScene(int scene)
        {
            if (scenes.Count < scene + 1)
            {
                throw new IndexOutOfRangeException($"Scene [{scene}] does not exist");
            }
        }

        public Level()
        {
            scenes.Add(new Scene());
        }
    }

    public class Scene
    {
        public Tilemap mainTilemap;

        private readonly List<EntityManagement.Entity> entities = new List<EntityManagement.Entity>();

        public List<EntityManagement.Entity> GetEntityList => entities;

        public float frameTime;

        public void AddEntity(EntityManagement.Entity newEntity, Vector2 position)
        {
            newEntity.position = position;
            UpdateEvent += newEntity.Update;
            entities.Add(newEntity);
        }

        public void Update()
        {
            UpdateEvent(this, EventArgs.Empty);
        }

        //Scene update event
        public event EventHandler UpdateEvent;
        protected virtual void OnUpdate(EventArgs e)
        {
            UpdateEvent?.Invoke(this, e);
        }

    }
}