﻿using Raylib_cs;
using System.Numerics;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Engine;

namespace Levels
{
    public class Tilemap
    {
        //Tileset
        private readonly Texture2D tileset = Raylib.LoadTexture("..\\..\\..\\Assets\\grassTiles.png");
        private readonly int tileWidth = 12;
        private readonly int tileHeight = 4;
        private readonly Tiling.Format tilesetFormat = Tiling.Tileset12x4;
        private Vector2 GetTileRec(int index)
        {
            int x = index % tileWidth;
            int y = (index - x) / tileWidth;

            return new Vector2(x, y);
        }

        //Tilemap
        private readonly byte?[,] tilemap = new byte?[512, 128];

        public byte?[,] GetTilemapData()
        {
            return tilemap;
        }

        public byte?[] GetTileColumn(int column)
        {
            byte?[] output = new byte?[tilemap.GetLength(1)];

            for (int y = 0; y < tilemap.GetLength(1); y++)
            {
                output[y] = tilemap[column, y];
            }

            return output;
        }

        public int GetTilemapWidth => tilemap.GetLength(0);
        public int GetTilemapHeight => tilemap.GetLength(1);

        public void SetTile(int x, int y, byte? id = 8)
        {
            if (x >= 0 && x < GetTilemapWidth && y >= 0 && y < GetTilemapHeight)
            tilemap[x, y] = id;
        }
        public void SetTilesRec(int startX, int startY, int endX, int endY, byte? id = 8)
        {   
            for (int x = startX; x <= endX; x++)
            {
                for (int y = startY; y <= endY; y++)
                {
                    SetTile(x, y, id);
                }
            }
        }
        public void FormatTilesRec(int startX, int startY, int endX, int endY)
        {
            startX = startX < 0 ? 0 : startX;
            startY = startY < 0 ? 0 : startY;
            endX = endX >= GetTilemapWidth ? GetTilemapWidth - 1 : endX;
            endY = endY >= GetTilemapHeight ? GetTilemapHeight - 1: endY;

            for (int x = startX; x <= endX; x++)
            {
                for (int y = startY; y <= endY; y++)
                {
                    if ((x >= 0 && y >=0) && tilemap[x, y].HasValue)
                    {
                        byte? tileIndex = null;
                        string code = Tiling.GetTilingCode(tilemap, x, y);
                        for (byte ry = 0; ry < tileHeight; ry++)
                        {
                            for (byte rx = 0; rx < tileWidth; rx++)
                            {
                                if (tilesetFormat.rules[rx, ry].CompareCode(code))
                                {
                                    tileIndex = (byte)((ry * tileWidth) + rx);
                                    ry = (byte)tileHeight;
                                    rx = (byte)tileWidth;
                                }
                            }
                        }
                        if (tileIndex != null)
                        {
                            tilemap[x, y] = tileIndex;
                        }
                        else
                        {
                            throw new Exception($"Failed to format tile at <{x}, {y}> " +
                                $"\nAttempted formatting code = {code}");
                        }
                    }
                }
            }
        }

        //Rendering
        public void DrawTile(int index, int x, int y)
        {
            int tileX = index % tileWidth;
            int tileY = (index - tileX) / tileWidth;

            int u = Screen.unitPixelSize * 16;
            Raylib.DrawTexturePro(
                tileset,
                new Rectangle(tileX * 16, tileY * 16, 16, 16),
                Rendering.GetScreenRect(new Rectangle(x, y, 1, 1)),
                new Vector2(0, 0),
                0f,
                Color.WHITE
                );
        }
        public void DrawTilesRec(int startX, int startY, int endX, int endY)
        {
            for (int x = startX; x <= endX; x++)
            {
                for (int y = startY; y <= endY; y++)
                {
                    if (tilemap[x, y].HasValue)
                    {
                        Vector2 tileSheetPos = GetTileRec((byte)tilemap[x, y]);

                        int u = Screen.unitPixelSize * 16;
                        Raylib.DrawTexturePro(
                            tileset,
                            new Rectangle(tileSheetPos.X * 16, tileSheetPos.Y * 16, 16, 16),
                            new Rectangle(x * u, (-y - 1) * u, u, u),
                            new Vector2(0, 0),
                            0f,
                            Color.WHITE
                            );
                    }
                }
            }
        }
        public void DrawAllTiles()
        {
            for (int x = 0; x < GetTilemapWidth; x++)
            {
                for (int y = 0; y < GetTilemapHeight; y++)
                {
                    if (tilemap[x, y].HasValue)
                    {
                        Vector2 tileSheetPos = GetTileRec((byte)tilemap[x, y]);

                        int u = Screen.unitPixelSize * 16;
                        Raylib.DrawTexturePro(
                            tileset,
                            new Rectangle(tileSheetPos.X * 16, tileSheetPos.Y * 16, 16, 16),
                            new Rectangle(x * u, (-y - 1) * u, u, u),
                            new Vector2(0, 0),
                            0f,
                            Color.WHITE
                            );
                    }
                }
            }
        }

        private const float gridZoomOutPoint = 0.2f;
        private const int largeGridScaleAmount = 8;
        private Color gridColor = new Color(100, 100, 100, 100);
        public void DrawGrid(float cameraZoom)
        {
            int s = 16 * Screen.unitPixelSize;
            int increment = cameraZoom > gridZoomOutPoint ? 1 : largeGridScaleAmount;

            for (int x = 0; x <= GetTilemapWidth; x += increment)
            {
                Raylib.DrawLine(x * s, 0, x * s, -GetTilemapHeight * s, gridColor);
            }
            for (int y = 0; y <= GetTilemapHeight; y += increment)
            {
                Raylib.DrawLine(0, -y * s, GetTilemapWidth * s, -y * s, gridColor);
            }
        }

        //Initialisation
        public Tilemap()
        {

        }
        public Tilemap(byte?[,] map)
        {
            tilemap = map;
        }
    }
}