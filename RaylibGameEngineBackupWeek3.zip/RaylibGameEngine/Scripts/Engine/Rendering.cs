﻿using Raylib_cs;
using System.Numerics;

namespace Engine
{
    public static class Rendering
    {
        public static float GetFrameTime()
        {
            return Raylib.GetFrameTime();
        }

        public static Rectangle GetScreenRect(Rectangle rect)
        {
            int u = Screen.unitPixelSize * Screen.pixelScale;
            return new Rectangle(rect.x * u, -rect.y * u, rect.width * u, rect.height * u);
        }
        public static Rectangle GetScreenRect(float x, float y, float width, float height)
        {
            int u = Screen.unitPixelSize * Screen.pixelScale;
            return new Rectangle(x * u, -y * u, width * u, height * u);
        }

        public static Vector2 WorldVector(Vector2 position)
        {
            return position * Screen.unitPixelSize * Screen.pixelScale * new Vector2(1, -1);
        }
        public static Vector2 WorldVector(float x, float y)
        {
            return new Vector2(x, -y) * Screen.unitPixelSize * Screen.pixelScale;
        }
    }
}