﻿using System.IO;
using System.Collections;

namespace Engine
{
    static class EntryPoint
    {
        public static void Main()
        {
            EditorPlus.Launch();
        }
    }
}