﻿using System;
using System.Collections.Generic;
using System.Numerics;
using System.Threading;
using Levels;
using Raylib_cs;

namespace Engine
{
    public static partial class EditorPlus
    {
        //Configuration Options
        public const int targetFramerate = 240;
        public static string levelPath = "TestLevel.lvl";
        public static Camera2D sceneCamera = new Camera2D
        {
            offset = new Vector2(Screen.screenWidth / 2, Screen.screenHeight / 2),
            target = new Vector2(0, 0),
            zoom = 1,
        };
        public static Color skyboxColor = new Color(184, 204, 216, 255);

        //Launch method
        public static void Launch()
        {
            //Initialisation
            Raylib.InitWindow(Screen.screenWidth, Screen.screenHeight, "EditorPlus");
            Raylib.SetTargetFPS(targetFramerate);

            //Update loop
            while (!Raylib.WindowShouldClose())
            {
                //Gather logic input
                Vector2 mousePosition = GetMouseWorldPosition();
                Console.WriteLine(mousePosition);

                //Execute editor logic

                //Execute GUI logic

                //Start drawing
                Raylib.BeginDrawing();
                Raylib.ClearBackground(skyboxColor);

                //Render scene
                Raylib.BeginMode2D(sceneCamera);
                Raylib.EndMode2D();

                //Render GUI

                //End drawing
                Raylib.EndDrawing();
            }

            //Termination
            Raylib.CloseWindow();
        }

        //Gets scaled mouse position relative to world grid
        public static Vector2 GetMouseWorldPosition()
        {
            Vector2 mousePos = Raylib.GetMousePosition();
            mousePos.Y = Screen.screenHeight - mousePos.Y;

            float screenTilesX = Screen.screenWidth / (Screen.unitPixelSize * 16) / sceneCamera.zoom;
            float screenTilesY = Screen.screenHeight / (Screen.unitPixelSize * 16) / sceneCamera.zoom;

            mousePos.X /= Screen.screenWidth / screenTilesX;
            mousePos.Y /= Screen.screenHeight / screenTilesY;

            Vector2 tileOffset = (sceneCamera.target - sceneCamera.offset * new Vector2(1, -1) / sceneCamera.zoom) / (16 * Screen.unitPixelSize) * new Vector2(1, -1);
            mousePos += tileOffset;

            return mousePos;
        }
    }
}