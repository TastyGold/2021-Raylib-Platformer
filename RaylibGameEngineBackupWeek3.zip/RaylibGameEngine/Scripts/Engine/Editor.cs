﻿using Raylib_cs;
using System.Numerics;
using System;
using Levels;

namespace Engine
{
    public static class Editor
    {
        public static async void LaunchEditor()
        {
            Raylib.InitWindow(Screen.screenWidth, Screen.screenHeight, "Editor");

            Level testLevel = new Level();
            testLevel.CreateNewScene(new Scene());
            testLevel.ActiveScene.AddEntity(new Player.PlayerCharacter() {
                scene = testLevel.ActiveScene
            }, new Vector2(10, 10));

            byte?[,] ts = await FileManager.ReadTilemapFromFile("TestLevel.lvl");
            Tilemap tm = new Tilemap(ts);
            testLevel.ActiveScene.mainTilemap = tm;
            Camera2D mainCamera = new Camera2D()
            {
                offset = new Vector2(Screen.screenWidth / 2, Screen.screenHeight / 2),
                target = new Vector2(Screen.screenWidth / 1.4f, -Screen.screenHeight / 1.4f),
                zoom = 1,
            };
            float cameraSpeed = 600;
            Raylib.SetTargetFPS(240);

            while (!Raylib.WindowShouldClose())
            {
                mainCamera.zoom *= 1 + Raylib.GetMouseWheelMove() / 10;
                float speedMod = Raylib.IsKeyDown(KeyboardKey.KEY_LEFT_SHIFT) ? 1.75f : 1;
                if (Raylib.IsKeyDown(KeyboardKey.KEY_W)) mainCamera.target += new Vector2(0, -1) * cameraSpeed * Raylib.GetFrameTime() / mainCamera.zoom * speedMod;
                if (Raylib.IsKeyDown(KeyboardKey.KEY_A)) mainCamera.target += new Vector2(-1, 0) * cameraSpeed * Raylib.GetFrameTime() / mainCamera.zoom * speedMod;
                if (Raylib.IsKeyDown(KeyboardKey.KEY_S)) mainCamera.target += new Vector2(0, 1) * cameraSpeed * Raylib.GetFrameTime() / mainCamera.zoom * speedMod;
                if (Raylib.IsKeyDown(KeyboardKey.KEY_D)) mainCamera.target += new Vector2(1, 0) * cameraSpeed * Raylib.GetFrameTime() / mainCamera.zoom * speedMod;
                
                Vector2 mousePos = Raylib.GetMousePosition();
                mousePos.Y = Screen.screenHeight - mousePos.Y;

                float screenTilesX = Screen.screenWidth / (Screen.unitPixelSize * 16) / mainCamera.zoom;
                float screenTilesY = Screen.screenHeight / (Screen.unitPixelSize * 16) / mainCamera.zoom;

                mousePos.X /= Screen.screenWidth / screenTilesX;
                mousePos.Y /= Screen.screenHeight / screenTilesY;

                Vector2 tileOffset = (mainCamera.target - mainCamera.offset * new Vector2(1, -1) / mainCamera.zoom) / (16 * Screen.unitPixelSize) * new Vector2(1, -1);
                mousePos += tileOffset;

                Raylib.BeginDrawing();
                Raylib.ClearBackground(new Color(184, 204, 216, 255));

                Raylib.BeginMode2D(mainCamera);
                testLevel.ActiveScene.Update();
                testLevel.ActiveScene.mainTilemap.DrawTilesRec(0, 0, 50, 20);
                testLevel.ActiveScene.mainTilemap.DrawGrid(mainCamera.zoom);
                testLevel.DrawActiveScene();
                Raylib.EndMode2D();


                if (Raylib.IsMouseButtonDown(MouseButton.MOUSE_LEFT_BUTTON))
                {
                    tm.SetTile((int)mousePos.X, (int)mousePos.Y);
                    tm.FormatTilesRec((int)mousePos.X - 1, (int)mousePos.Y - 1, (int)mousePos.X + 1, (int)mousePos.Y + 1);
                }
                if (Raylib.IsMouseButtonDown(MouseButton.MOUSE_RIGHT_BUTTON))
                {
                    tm.SetTile((int)mousePos.X, (int)mousePos.Y, null);
                    tm.FormatTilesRec((int)mousePos.X - 1, (int)mousePos.Y - 1, (int)mousePos.X + 1, (int)mousePos.Y + 1);
                }

                if (Raylib.IsKeyPressed(KeyboardKey.KEY_ENTER) && Raylib.IsKeyDown(KeyboardKey.KEY_LEFT_CONTROL))
                {
                    await FileManager.WriteTilemapToFile(testLevel.ActiveScene.mainTilemap, "TestLevel.lvl");
                }


                Raylib.DrawFPS(10, 10);

                Raylib.EndDrawing();
            }

            Raylib.CloseWindow();
        }
    }
}