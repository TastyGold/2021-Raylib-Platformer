﻿namespace Engine
{
    public static class Screen
    {
        public const int screenWidth = 1600;
        public const int screenHeight = 900;
        public const int unitPixelSize = 4;
        public const int pixelScale = 16;
    }
}