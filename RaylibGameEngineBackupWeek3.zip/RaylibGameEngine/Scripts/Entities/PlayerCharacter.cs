﻿using System;
using System.Numerics;
using System.Collections.Generic;
using Engine;
using Raylib_cs;
using Levels;

namespace Player
{
    public static class PlayerData
    {

    }

    public class PlayerCharacter : EntityManagement.BoxCollider
    {
        public Scene scene;

        public Texture2D sprite = Raylib.LoadTexture("..\\..\\..\\Assets\\Character.png");
        public Vector2 spriteOffset;

        public override void RunBehaviour()
        {
            if (Raylib.IsKeyDown(KeyboardKey.KEY_RIGHT)) 
                position += new Vector2(1, 0) * 5 * Rendering.GetFrameTime();
            if (Raylib.IsKeyDown(KeyboardKey.KEY_UP))
                position += new Vector2(0, 1) * 5 * Rendering.GetFrameTime();
            if (Raylib.IsKeyDown(KeyboardKey.KEY_LEFT))
                position += new Vector2(-1, 0) * 5 * Rendering.GetFrameTime();
            if (Raylib.IsKeyDown(KeyboardKey.KEY_DOWN))
                position += new Vector2(0, -1) * 5 * Rendering.GetFrameTime();

            HandleCollision();
        }

        private void HandleCollision()
        {
            Vector2 escapeVector = Vector2.Zero;

            List<Vector2> collisionTileChecks = GetTileOverlaps(1f);
            foreach (Vector2 vector in collisionTileChecks)
            {
                Vector2 v = new Vector2(vector.X, -vector.Y);
                Raylib.DrawRectangleLinesEx(Rendering.GetScreenRect(v.X, v.Y + 1, 1, 1), 1, Color.WHITE);
                
                Raylib.DrawLineV(
                    Rendering.WorldVector(position),
                    Rendering.WorldVector(v + (Vector2.One * 0.5f)), 
                    Color.MAGENTA
                    );

                if (scene.mainTilemap.GetTilemapData()[(int)v.X, (int)v.Y].HasValue && IsOverlapping(v, out float xDist, out float yDist))
                {
                    if (Math.Abs(yDist) - (hitboxSize.Y / 2) > Math.Abs(xDist) - (hitboxSize.X / 2))
                    {
                        escapeVector.Y = yDist + (yDist <= 0 ? minTileDist.Y : -minTileDist.Y);
                    }
                    else
                    {
                        escapeVector.X = xDist + (xDist < 0 ? minTileDist.X : -minTileDist.X);
                    }
                }
            }

            position += escapeVector;
        }

        public override void Draw()
        {
            Raylib.DrawTextureEx(sprite, Rendering.WorldVector(position + spriteOffset), 0, 1 * Screen.unitPixelSize, Color.WHITE);
        }

        public PlayerCharacter()
        {
            hitboxSize = new Vector2(0.875f, 1.5f);
            position = Vector2.Zero;
            sprite = Raylib.LoadTexture("..\\..\\..\\Assets\\Character.png");
            spriteOffset = new Vector2(-0.5f, 0.75f);
            hitboxOffset = spriteOffset;
        }
    }
}