﻿using Engine;
using System;
using System.Collections.Generic;
using System.Numerics;
using Raylib_cs;

namespace Levels
{
    public static partial class EntityManagement
    {
        //Interface for entity behavious in a scene
        public interface IScripted
        {
            public void RunBehaviour();
        }

        public interface IDrawable
        {
            public void Draw();
        }

        //Entity class
        public abstract class Entity : IScripted
        {
            // generic entity data
            public Vector2 position;
            public Vector2 tilePosition => new Vector2(
                (int)Math.Floor(position.X),
                (int)Math.Floor(position.Y));

            public void Update(object sender, EventArgs e)
            {
                RunBehaviour();
            }

            public abstract void RunBehaviour();

            public abstract void Draw();
        }

        public class BoxCollider : Entity
        {
            public Vector2 hitboxSize;
            public Vector2 hitboxOffset;

            public Vector2 minTileDist => (hitboxSize + Vector2.One) / 2;

            public override void RunBehaviour()
            {
                throw new NotImplementedException();
            }

            public override void Draw()
            {
                Raylib.DrawRectanglePro(Rendering.GetScreenRect(position.X, position.Y, 1, 1), Rendering.WorldVector(0, 1), 0, new Color(220, 220, 220, 255));
            }

            public List<Vector2> GetTileOverlaps(float padding = 0f)
            {
                Vector2 cornerA = position - (hitboxSize / 2) - (Vector2.One * padding);
                Vector2 cornerB = position + (hitboxSize / 2) + (Vector2.One * padding);

                cornerA = new Vector2((int)Math.Floor(cornerA.X), (int)Math.Floor(cornerA.Y));
                cornerB = new Vector2((int)Math.Ceiling(cornerB.X), (int)Math.Ceiling(cornerB.Y));

                List<Vector2> tiles = new List<Vector2>();

                for (int x = (int)cornerA.X; x < (int)cornerB.X; x++)
                {
                    for (int y = (int)cornerA.Y; y < (int)cornerB.Y; y++)
                    {
                        tiles.Add(new Vector2(x, -y));
                    }
                }

                return tiles;
            }

            public bool IsOverlapping(Vector2 tile, out float xDist, out float yDist)
            {
                Vector2 tileCenter = tile + Vector2.One * 0.5f;
                xDist = tileCenter.X - position.X;
                yDist = tileCenter.Y - position.Y;

                return Math.Abs(xDist) < 0.5f + (hitboxSize.X / 2) && Math.Abs(yDist) < 0.5f + (hitboxSize.Y / 2);
            }
        }
    }
}