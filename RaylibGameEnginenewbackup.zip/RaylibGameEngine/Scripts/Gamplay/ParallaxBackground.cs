﻿using Raylib_cs;
using System.Numerics;
using MathExtras;

namespace Engine
{
    public class ParallaxBackground
    {
        //Variables
        public const string filePrefix = "..\\..\\..\\Assets\\Backgrounds\\";

        public SpriteSheet spritesheet;
        public readonly int layers;
        public float[] parallaxValues; //back to front

        //Methods
        public void Draw(Vector2 cameraPosition)
        {
            for (int i = 0; i < parallaxValues.Length; i++)
            {
                Raylib.DrawTextureTiled(
                    spritesheet.texture,
                    spritesheet.GetSourceRec(i),
                    GetLayerScreenRec(i, cameraPosition),
                    Vector2.Zero, 0, Screen.scalar, Color.WHITE
                    );

            }
        }
        public virtual Rectangle GetLayerScreenRec(int layer, Vector2 cameraPosition)
        {
            float x = -cameraPosition.X * (1 - parallaxValues[layer]) * Screen.scalar;
            float sx = spritesheet.spriteSizeX * Screen.scalar;
            float sy = spritesheet.spriteSizeY * Screen.scalar;

            return new Rectangle((x % sx) - sx, 0, sx * 3, sy);
        }

        //Initialisation
        public ParallaxBackground(string texture, float[] values)
        {
            Texture2D tex = Raylib.LoadTexture(filePrefix + texture);
            int width = tex.width;
            int height = tex.height / values.Length;

            spritesheet = new SpriteSheet(new Vector2Int(width, height), tex);
            parallaxValues = values;
            layers = spritesheet.SpritesHigh;
        }
    }

    public class ScrollingParallaxBackground : ParallaxBackground
    {
        //Variables
        public float[] scrollingValues;

        //Methods
        public override Rectangle GetLayerScreenRec(int layer, Vector2 cameraPosition)
        {
            float x = -cameraPosition.X * (1 - parallaxValues[layer]) * Screen.scalar;
            float sx = spritesheet.spriteSizeX * Screen.scalar;
            float sy = spritesheet.spriteSizeY * Screen.scalar;
            x += Clock.GameTime * 0.016f * scrollingValues[layer] * Screen.scalar;

            return new Rectangle((x % sx) - sx, 0, sx * 3, sy);
        }

        //Initialisation
        public ScrollingParallaxBackground(string texture, float[] values, float[] scrollingValues) : base(texture, values)
        {
            this.scrollingValues = scrollingValues;
        }
    }
}