﻿using System;
using Engine;
using Levels;
using Raylib_cs;
using System.Collections.Generic;
using System.Numerics;
using Player;

namespace Engine
{
    public static class Gameplay
    {
        public static bool debugEnabled = true;

        private const int targetFPS = 60;
        private const float targetFrameTime = 1 / (float)targetFPS;
        private const float maxDroppedFrames = 10;
        public static int executedFrames = 1;

        public static Camera2D playerCamera = new Camera2D
        {
            offset = new Vector2(Screen.screenWidth / 2, Screen.screenHeight / 2),
            target = new Vector2(Screen.screenWidth / 2, Screen.screenHeight / -2),
            zoom = 1f,
        };
        private static ScrollingParallaxBackground sceneBackground = new ScrollingParallaxBackground(
            "colouredBackgroundSheet.png",
            new float[4] { 1f, 0.99f, 0.98f, 0.96f },
            new float[4] { 0f, -0.25f, -0.4f, 0f }
            );

        public static Vector2 spawnpoint = Vector2.One * 10;

        public static async void Launch()
        {
            Raylib.InitWindow(Screen.screenWidth, Screen.screenHeight, "Player");
            Raylib.SetTargetFPS(targetFPS);

            Level gameplayLevel = await FileManager.ReadLevelFromFile(EntryPoint.levelPath);

            gameplayLevel.ActiveScene.AddEntity(
                new PlayerCharacter()
                {
                    scene = gameplayLevel.ActiveScene,
                },
                new Vector2(10, 10)
            );
            
            gameplayLevel.ActiveScene.BakeTilemapToTexture();
            gameplayLevel.ActiveScene.RecalculateSemisolidOrdering();

            Clock.Start();
            while (!Raylib.WindowShouldClose())
            {
                //Diagnostics + Debug
                Rendering.ResetDrawCalls();
                DebugText.Clear();
                if (Raylib.IsKeyPressed(KeyboardKey.KEY_F3)) debugEnabled = !debugEnabled;

                //Compensate fram drops
                if (Clock.DeltaTime >= targetFrameTime * maxDroppedFrames)
                {
                    executedFrames = (int)Math.Round(Clock.DeltaTime / targetFrameTime);
                    Console.WriteLine($"Frame drop: {(int)(Clock.DeltaTime * 1000)}ms ({Math.Round(Clock.DeltaTime / targetFrameTime) - 1})");
                }
                else
                {
                    executedFrames = 1;
                }

                //Handle game logic
                gameplayLevel.ActiveScene.Update();

                //Begin drawing
                Raylib.BeginDrawing();
                Raylib.ClearBackground(Color.WHITE);
                sceneBackground.Draw(playerCamera.target);

                //Render scene
                Raylib.BeginMode2D(playerCamera);
                gameplayLevel.DrawActiveScene();

                Raylib.EndMode2D();

                //Render overlays
                if (debugEnabled)
                {
                    DebugText.DrawBackground();
                    DebugText.WriteTitle("DEBUG MODE");
                    DebugText.WriteFPS();
                    DebugText.Write("Draw calls", Rendering.DrawCalls);
                    DebugText.Write("Delta Time", Clock.DeltaTime);
                    DebugText.WriteTickets();
                }

                //Stop drawing
                Raylib.EndDrawing();

                //Clock
                Clock.Count();
                Clock.AdvanceDeltaTime();
            }

            Raylib.CloseWindow();
        }
    }
}