﻿using System;
using System.Numerics;
using System.IO;
using Engine;

namespace MathExtras
{
    public static class Vect
    {
        public static Vector2 Up => new Vector2(0, 1);
        public static Vector2 Down => new Vector2(0, -1);
        public static Vector2 Left => new Vector2(-1, 0);
        public static Vector2 Right => new Vector2(1, 0);
        public static Vector2 FlipY => new Vector2(1, -1);
        public static Vector2 FlipX => new Vector2(-1, 1);

        public static Vector2 Floor(this Vector2 vector)
        {
            return new Vector2((float)Math.Floor(vector.X), (float)Math.Floor(vector.Y));
        }
        public static Vector2 Ceiling(this Vector2 vector)
        {
            return new Vector2((float)Math.Ceiling(vector.X), (float)Math.Ceiling(vector.Y));
        }
        public static Vector2 RoundXY(this Vector2 vector)
        {
            return new Vector2(
                vector.X % 1 < 0.5f ? (int)vector.X : (int)vector.X + 1,
                vector.Y % 1 < 0.5f ? (int)vector.Y : (int)vector.Y + 1
                );
        }
        public static Vector2 Normalise(this Vector2 vector)
        {
            if (vector.X != 0 && vector.Y != 0)
            {
                return vector / vector.Length();
            }
            else
            {
                return vector;
            }
        }
        public static Vector2Int ToVector2Int(this Vector2 vector)
        {
            return new Vector2Int((int)vector.X, (int)vector.Y);
        }

        public static string ToString(this Vector2 vector, int decimalPlaces)
        {
            return $"<{Math.Round(vector.X, decimalPlaces)}, {Math.Round(vector.Y, decimalPlaces)}>";
        }
    }

    public enum Direction
    {
        Down,
        Left,
        None,
        Right,
        Up,
    }

    public struct Vectex
    {
        //Variables
        public Vector2 min;
        public Vector2 max;

        //Initialisation
        public Vectex(Vector2 a, Vector2 b)
        {
            min = new Vector2(a.X < b.X ? a.X : b.X, a.Y < b.Y ? a.Y : b.Y);
            max = new Vector2(a.X >= b.X ? a.X : b.X, a.Y >= b.Y ? a.Y : b.Y);
        }
        public Vectex(float ax, float ay, float bx, float by)
        {
            min = new Vector2(ax < bx ? ax : bx, ay < by ? ay : by);
            max = new Vector2(ax >= bx ? ax : bx, ay >= by ? ay : by);
        }

        //Methods
        public Vectex SwapY() => new Vectex()
        {
            min = new Vector2(min.X, max.Y),
            max = new Vector2(max.X, min.Y)
        };

        //Overrides
        public override string ToString()
        {
            return $"{min.ToString()}, {max.ToString()}";
        }
    }

    public struct Vector2Int
    {
        //Variables
        public int X;
        public int Y;

        //Initilisation
        public Vector2Int(int x, int y)
        {
            X = x;
            Y = y;
        }
        public Vector2Int(Vector2 vector)
        {
            X = (int)vector.X;
            Y = (int)vector.Y;
        }

        //Constants
        public static Vector2Int Zero => new Vector2Int(0, 0);

        //Math
        public int LengthSquared => (X * X) + (Y * Y);
        public float Length => (float)Math.Sqrt(LengthSquared);

        //Operators
        public static Vector2Int operator +(Vector2Int a, Vector2Int b) => new Vector2Int(a.X + b.X, a.Y + b.Y);
        public static Vector2Int operator -(Vector2Int a, Vector2Int b) => new Vector2Int(a.X - b.X, a.Y - b.Y);
        public static Vector2Int operator *(Vector2Int a, Vector2Int b) => new Vector2Int(a.X * b.X, a.Y * b.Y);
        public static Vector2Int operator /(Vector2Int a, Vector2Int b) => new Vector2Int(a.X / b.X, a.Y / b.Y);
        public static explicit operator Vector2Int(Vector2 v)
        {
            return new Vector2Int((int)v.X, (int)v.Y);
        } 

        //Overrides
        public override string ToString()
        {
            return $"<{X.ToString()}, {Y.ToString()}>";
        }
        public override bool Equals(object obj)
        {
            if (obj is Vector2Int)
            {
                return ((Vector2Int)obj).X == X && ((Vector2Int)obj).Y == Y;
            }
            return false;
        }
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }

    public static class Intersection
    {
        public static bool AABB(Vector2 positionA, Vector2 sizeA, Vector2 positionB, Vector2 sizeB)
        {
            return Math.Abs(positionB.X - positionA.X) < (sizeA.X + sizeB.X)
                && Math.Abs(positionB.Y - positionA.Y) < (sizeA.Y + sizeB.Y);
        }
        public static bool AABB(Vectex a, Vectex b)
        {
            return !(a.min.X > b.max.X || a.max.X < b.min.X || a.max.Y < b.min.Y || a.min.Y > b.min.Y);
        }
        public static bool OverlapTile(Vector2 position, Vector2 hitboxSize, Vector2Int tile)
        {
            return OverlapTileX(position, hitboxSize, tile) && OverlapTileY(position, hitboxSize, tile);
        }
        public static bool OverlapTileX(Vector2 position, Vector2 hitboxSize, Vector2Int tile)
        {
            return Math.Abs(position.X - tile.X) < (hitboxSize.X / 2) + 0.5f;
        }
        public static bool OverlapTileY(Vector2 position, Vector2 hitboxSize, Vector2Int tile)
        {
            return Math.Abs(position.Y - tile.Y) < (hitboxSize.Y / 2) + 0.5f;
        }
    }

    public static class MathP
    {
        /// <summary>
        /// Linearly interpolates between two values.
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <param name="t">eg: 0 = a , 1 = b , 0.5 = ab/2</param>
        /// <returns></returns>
        public static float Lerp(float a, float b, float t)
        {
            return a + ((b - a) * t);
        }
        /// <summary>
        /// Returns value a interpolated towards value b, with a maximum step value.
        /// Result will not exceed value b.
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <param name="maxStep"></param>
        /// <returns></returns>
        public static float StepTowards(float a, float b, float maxStep)
        {
            if (Math.Abs(b - a) < maxStep || a == b)
            {
                return b;
            }
            else
            {
                return a + (maxStep * (b > a ? 1 : -1));
            }
        }
        /// <summary>
        /// Simplified division for simple numbers, returns whole number (rounds up)
        /// </summary>
        /// <param name="value"></param>
        /// <param name="step"></param>
        /// <returns></returns>
        public static int CountBack(this float value, float step)
        {
            int steps = 0;
            while (value > step)
            {
                value -= step;
                steps++;
            }
            return steps;
        }

        public enum Sign
        {
            Positive, Negative, Zero
        }
        public static Sign GetSign(this float f)
        {
            if (f == 0) return Sign.Zero;
            return f < 0 ? Sign.Negative : Sign.Positive;
        }
        public static bool HasSimilarSign(this Sign s, Sign c)
        {
            return c == Sign.Zero || s == Sign.Zero || c == s;
        }
    }
}