﻿using System;
using MathExtras;
using Raylib_cs;

namespace Engine
{
    public struct SpriteSheet
    {
        public Texture2D texture;

        public ushort spriteSizeX;
        public ushort spriteSizeY;

        public ushort SpritesWide => (ushort)(texture.width / spriteSizeX);
        public ushort SpritesHigh => (ushort)(texture.height / spriteSizeY);

        public Rectangle GetSourceRec(int index)
        {
            int xPos = index % SpritesWide;
            int yPos = (index - xPos) / SpritesWide;

            return new Rectangle(xPos * spriteSizeX, yPos * spriteSizeY, spriteSizeX, spriteSizeY);
        }
        public Rectangle GetSourceRec(int x, int y)
        {
            if (x > SpritesWide || y > SpritesHigh)
            {
                throw new System.ArgumentOutOfRangeException();
            }
            return new Rectangle(x * spriteSizeX, y * spriteSizeY, spriteSizeX, spriteSizeY);
        }

        //Initialisation
        public SpriteSheet(Vector2Int spriteRes, string filePath)
        {
            texture = Raylib.LoadTexture(filePath);
            spriteSizeX = (ushort)spriteRes.X;
            spriteSizeY = (ushort)spriteRes.Y;
        }
        public SpriteSheet(int spriteRes, string filePath)
        {
            this = new SpriteSheet(new Vector2Int(spriteRes, spriteRes), filePath);
        }
        public SpriteSheet(Vector2Int spriteRes, Texture2D texture)
        {
            this.texture = texture;
            spriteSizeX = (ushort)spriteRes.X;
            spriteSizeY = (ushort)spriteRes.Y;
        }
        public SpriteSheet(int spriteRes, Texture2D texture)
        {
            this = new SpriteSheet(new Vector2Int(spriteRes, spriteRes), texture);
        }

        //Prefabs
        public static SpriteSheet standardGrass = new SpriteSheet(16, Raylib.LoadTexture("..\\..\\..\\Assets\\Semisolids\\tilesetsemisolid.png"));
    }

    public class Animation
    {
        //Variables
        public readonly int frames;
        public float framesPerSecond;
        public Vector2Int offset;
        public ScrollType scrollType = ScrollType.Horizontal;
        public bool looping = true;

        //Timer
        private DateTime lastAnimTime = DateTime.Now;
        private float animTimer = 0f; //timer for the animation in ms
        private bool countingTimer = true;
        private float FrameDuration => 1000 / framesPerSecond;
        private float Duration => frames * FrameDuration;

        private void UpdateAnimTimer()
        {
            animTimer += (float)DateTime.Now.Subtract(lastAnimTime).TotalMilliseconds;
            lastAnimTime = DateTime.Now;
            if (animTimer >= Duration)
                animTimer %= Duration;
        }

        //Methods
        public void Play()
        {
            countingTimer = true;
        }
        public void Reset()
        {
            animTimer = 0f;
            lastAnimTime = DateTime.Now;
        }
        public void Stop()
        {
            countingTimer = false;
            Reset();
        }
        public void Pause()
        {
            countingTimer = false;
        }

        private int CurrentFrameIndex => animTimer.CountBack(FrameDuration);
        public Vector2Int GetCurrentFrame()
        {
            if (countingTimer) UpdateAnimTimer();
            return offset + (scrollType == ScrollType.Horizontal ? new Vector2Int(CurrentFrameIndex, 0) : new Vector2Int(0, CurrentFrameIndex));
        }

        //Initialisation
        public Animation(int frames, int framesPerSecond, Vector2Int offset, ScrollType scrollType = ScrollType.Horizontal)
        {
            this.frames = frames;
            this.framesPerSecond = framesPerSecond;
            this.offset = offset;
            this.scrollType = scrollType;
        }

        //Scroll types
        public enum ScrollType
        {
            Horizontal,
            Vertical
        }
    }
}