﻿using System;
using System.Numerics;
using System.Collections.Generic;
using Engine;
using Raylib_cs;
using Levels;
using MathExtras;

namespace Player
{
    public partial class PlayerCharacter : EntityManagement.BoxCollider
    {
        private void HandleCollision(float deltaTime, out bool colliding, out Vector2 escapeVector)
        {
            escapeVector = Vector2.Zero;
            colliding = false;

            //Semisolid collision
            if (velocity.Y <= 0)
            {
                List<Semisolid> overlappingSemisolids = scene.semisolids.GetSemisolidOverlaps(GetHitboxVectexPadded(0.5f));
                foreach (Semisolid s in overlappingSemisolids)
                {
                    if (s.hasSurface && s.x + Semisolid.colliderTrimming < position.X + (hitboxSize.X / 2) && s.x + s.width - Semisolid.colliderTrimming > position.X - (hitboxSize.X / 2))
                    {
                        float surfaceLeniency = velocity.Y < -1f ? 0 : Semisolid.surfaceDepthLeniency;
                        if (ColliderPosition.Y - (hitboxSize.Y / 2) - (velocity.Y * deltaTime * 2) >= s.y + s.height - surfaceLeniency && ColliderPosition.Y - (hitboxSize.Y / 2) < s.y + s.height)
                        {
                            escapeVector.Y = s.y + s.height - (ColliderPosition.Y - (hitboxSize.Y / 2)) + float.Epsilon;
                            colliding = true;
                        }
                        else
                        {
                        }
                    }
                }
            }

            //Tile collision
            List<Vector2> collisionTileChecks = GetTileOverlaps(0.25f);
            foreach (Vector2 vector in collisionTileChecks)
            {
                Vector2 v = new Vector2(vector.X, -vector.Y);

                if (scene.mainTilemap.GetTileData((int)v.X, (int)v.Y).HasValue && IsOverlapping(v, out float xDist, out float yDist))
                {
                    //Whichever axis the player's hitbox is shallower in will determine the direction of the vector
                    if (Math.Abs(yDist) - (hitboxSize.Y / 2) > Math.Abs(xDist) - (hitboxSize.X / 2) + deltaTime)
                    {
                        bool escapeFromAbove = yDist <= 0;
                        if (!scene.mainTilemap.GetTileData((int)v.X, (int)v.Y + (escapeFromAbove ? 1 : -1)).HasValue)
                        {
                            escapeVector.Y = yDist + (escapeFromAbove ? minTileDist.Y : -minTileDist.Y);
                            colliding = true;
                        }
                    }
                    else if (Math.Abs(yDist) - (hitboxSize.Y / 2) < Math.Abs(xDist) - (hitboxSize.X / 2) - deltaTime)
                    {
                        bool escapeFromRight = xDist < 0;
                        if (!scene.mainTilemap.GetTileData((int)v.X + (escapeFromRight ? 1 : -1), (int)v.Y).HasValue)
                        {
                            escapeVector.X = xDist + (escapeFromRight ? minTileDist.X : -minTileDist.X);
                            colliding = true;
                        }
                    }
                }
            }

            position += escapeVector;
        }
    }
}