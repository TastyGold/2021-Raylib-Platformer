﻿using Engine;
using System;
using System.Numerics;
using Raylib_cs;
using Levels;
using MathExtras;

namespace Player
{
    public partial class PlayerCharacter : EntityManagement.BoxCollider
    {
        //Config
        private const float cameraHorizontalLerpSpeed = 5f;
        private const float cameraVerticalCatchupSpeed = 4f;
        private const float cameraAscendingCatchupDistance = 2f;
        private const float cameraDescengingCatchupDistance = 1f;
        private Vector2 cameraOffset = Vect.Up * 0.5f;

        //Runtime
        private Vector2 cameraTarget;
        private float cameraHeight = 30;

        //Methods
        public void HandleCameraMovement()
        {
            //cameraTarget.X = MathP.Lerp(cameraTarget.X, position.X, cameraHorizontalLerpSpeed * Clock.DeltaTime);
            cameraTarget.X = position.X;

            if (cameraHeight > position.Y + cameraDescengingCatchupDistance)
            {
                cameraHeight = position.Y + cameraDescengingCatchupDistance;
            }
            else if (cameraHeight < position.Y - cameraAscendingCatchupDistance)
            {
                cameraHeight = position.Y - cameraAscendingCatchupDistance;
            }
            else if (groundedByCollision && cameraHeight < position.Y)
            {
                cameraTarget.Y = MathP.Lerp(cameraTarget.Y, cameraHeight, cameraVerticalCatchupSpeed / 2 * Clock.DeltaTime);
            }

            cameraTarget.Y = MathP.Lerp(cameraTarget.Y, cameraHeight, cameraVerticalCatchupSpeed * Clock.DeltaTime);

            UpdateCameraPosition();
        }
        public void UpdateCameraPosition()
        {
            Gameplay.playerCamera.target = Rendering.WorldVector(cameraTarget + cameraOffset).RoundXY();

            //crude camera bounding
            if (Gameplay.playerCamera.target.X - Gameplay.playerCamera.offset.X < 0) 
                Gameplay.playerCamera.target.X = Gameplay.playerCamera.offset.X;
            if (Gameplay.playerCamera.target.Y + Gameplay.playerCamera.offset.Y > 0)
                Gameplay.playerCamera.target.Y = -Gameplay.playerCamera.offset.Y;
            
        }
    }
}