﻿using System;
using System.Numerics;
using System.Collections.Generic;
using Engine;
using Raylib_cs;
using Levels;
using MathExtras;

namespace Player
{
    public partial class PlayerCharacter : EntityManagement.BoxCollider
    {
        //Configuration
        public SpriteSheet spriteSheet = new SpriteSheet(new Vector2Int(16, 24), "..\\..\\..\\Assets\\playerSpriteSheet.png");
        public Vector2 spriteOffset;
        public Animation walkAnim = new Animation(4, 12, new Vector2Int(3, 0));
        public bool isFacingRight = true;

        public Rectangle GetCurrentSpriteRec()
        {
            Vector2Int spritePos = new Vector2Int();
            float xv = Math.Abs(velocity.X);

            if (!isCrouching)
            {
                if (groundedByCollision)
                {
                    if (xv > 1f )// && xv < 10f)
                    {
                        walkAnim.framesPerSecond = 4 + xv; //walking
                        spritePos.X = walkAnim.GetCurrentFrame().X;
                    }
                    else
                    {
                        spritePos.X = 0;
                    }
                }
                else
                {
                    if (velocity.Y < -6f)
                    {
                        spritePos.X = 2; //falling
                    }
                    else
                    {
                        spritePos.X = 0; //in the air
                    }
                }
            }
            else
            {
                spritePos.X = 1;
            }

            if (velocity.X < 0)
            {
                isFacingRight = false;
            }
            else if (velocity.X > 0)
            {
                isFacingRight = true;
            }

            spritePos.Y = isFacingRight ? 0 : 1;

            return new Rectangle(
                spritePos.X * spriteSheet.spriteSizeX,
                spritePos.Y * spriteSheet.spriteSizeY,
                spriteSheet.spriteSizeX,
                spriteSheet.spriteSizeY);
        }

        public override void Draw()
        {
            Vector2 destRecPosition = Rendering.WorldVector(position.X + spriteOffset.X, position.Y + spriteOffset.Y).RoundXY();
            Rectangle destRec = new Rectangle(destRecPosition.X, destRecPosition.Y, Screen.pixelScale * Screen.unitPixelSize, Screen.pixelScale * (Screen.unitPixelSize * 1.5f));
            Raylib.DrawTexturePro(spriteSheet.texture, GetCurrentSpriteRec(), destRec, Vector2.Zero, 0, Color.WHITE);
            Rendering.CountDrawCall();
        }
    }
}