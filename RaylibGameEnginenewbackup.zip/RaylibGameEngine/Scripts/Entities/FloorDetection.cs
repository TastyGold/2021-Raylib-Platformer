﻿using Levels;
using MathExtras;
using System.Numerics;
using Engine;
using System;

namespace Player
{
    public partial class PlayerCharacter : EntityManagement.BoxCollider
    {
        private Vector2 floorDetectionSize = new Vector2(0.85f, 0.05f);
        private Vector2 floorDetectionOffset => Vect.Down * (hitboxSize.Y / 2 + 0.0625f);
        public bool IsGrounded => DetectFloor();

        private bool groundedByCollision = false;

        private bool DetectFloor()
        {
            if (scene.mainTilemap.OverlapRec(new Vectex(position + (floorDetectionOffset - (floorDetectionSize / 2)), position + (floorDetectionOffset + (floorDetectionSize / 2)))))
            {
                return true;
            }
            return false;
        }

        public void DrawFloorDetection(Raylib_cs.Color color)
        {
            Raylib_cs.Raylib.DrawRectangleV(Rendering.WorldVector(position) + Rendering.WorldVector(floorDetectionOffset - (floorDetectionSize / 2 * Vect.FlipY)), Vect.FlipY * Rendering.WorldVector(floorDetectionSize), color);
            Rendering.CountDrawCall();        
        }
    }
}