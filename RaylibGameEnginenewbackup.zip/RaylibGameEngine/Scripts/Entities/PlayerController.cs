﻿using System;
using System.Numerics;
using System.Collections.Generic;
using Engine;
using Raylib_cs;
using Levels;
using MathExtras;

namespace Player
{
    public static class PlayerData
    {

    }

    public partial class PlayerCharacter : EntityManagement.BoxCollider
    {
        //Movement Profiles
        private MovementProfile walk = new MovementProfile()
        {
            groundSpeed = 8f,
            airSpeed = 8f,
            groundAcceleration = 12f,
            groundDeceleration = 20f,
            airAcceleration = 11f,
            airDeceleration = 14f,
            groundHardTurn = 40f,
            airHardTurn = 30f,
        };
        private MovementProfile sprint = new MovementProfile()
        {
            groundSpeed = 10.5f,
            airSpeed = 10.5f,
            groundAcceleration = 3f,
            groundDeceleration = 40f,
            airAcceleration = 1.5f,
            airDeceleration = 22f,
            groundHardTurn = 40f,
            airHardTurn = 30f,
        };
        private MovementProfile crouch = new MovementProfile()
        {
            groundSpeed = 0f,
            airSpeed = 8f,
            groundAcceleration = 7f,
            groundDeceleration = 14f,
            airAcceleration = 6f,
            airDeceleration = 20f,
            groundHardTurn = 20f,
            airHardTurn = 15f,
        };
        private MovementProfile ActiveMovementProfile => isCrouching ? crouch :
            (Math.Abs(velocity.X) >= walk.groundSpeed ? sprint : walk);

        //Moving
        private static bool hardTurning;
        private static float hardTurningSpeed;
        private static bool hardTurningRight;
        private static bool facingRight = true;

        //Crouching
        private static bool isCrouching = false;

        //Jumping
        private const float gravity = 35;
        private const float jumpForce = 10.5f;
        private const float jumpRiseTiles = 1.2f;
        private const float sprintJumpRise = 0.8f;
        private const float minHighJumpSpeed = 3f;
        private const float jumpHeldGravityMod = 0.5f;
        private const float jumpCancelStopper = 0.6f;
        private const float terminalVelocity = 14f;
        private float GetJumpRise()
        {
            return MathP.Lerp(jumpRiseTiles, jumpRiseTiles + sprintJumpRise,
                Math.Min(Math.Max(Math.Abs(velocity.X) - minHighJumpSpeed, 0) / (sprint.groundSpeed - minHighJumpSpeed), 1));
        }
        private float jumpedFromHeight;


        //Scene reference
        public Scene scene;

        //Runtime
        public Vector2 velocity = Vector2.Zero;

        private void HandleMovement(Vector2 input, int iterations)
        {
            float frameTime = Clock.DeltaTime / (float)iterations;
            Vector2 wasdInput = input;

            for (int i = 0; i < iterations; i++)
            {
                bool reached = hardTurning && (
                    (hardTurningRight && velocity.X > hardTurningSpeed) ||
                    (!hardTurningRight && velocity.X < hardTurningSpeed)
                    );

                if (wasdInput.X != 0 && !reached && !wasdInput.X.GetSign().HasSimilarSign(velocity.X.GetSign()))
                {
                    if (!hardTurning)
                    {
                        hardTurning = true;
                        hardTurningRight = wasdInput.X > 0;
                        hardTurningSpeed = -velocity.X / 2;
                    }
                }
                else
                {
                    hardTurning = false;
                    hardTurningSpeed = 0;
                }

                //Updating velocity based on input
                if (wasdInput.X != 0)
                {
                    float step;
                    if (hardTurning)
                    {
                        step = groundedByCollision ? 
                            ActiveMovementProfile.groundHardTurn : ActiveMovementProfile.airHardTurn;
                    }
                    else
                    {
                        step = groundedByCollision ? 
                            ActiveMovementProfile.groundAcceleration : ActiveMovementProfile.airAcceleration;
                    }

                    float profileSpeed = groundedByCollision ? 
                        ActiveMovementProfile.groundSpeed : ActiveMovementProfile.airSpeed;

                    velocity.X = MathP.StepTowards(velocity.X, profileSpeed * wasdInput.X, step * frameTime);
                }
                else
                {
                    float profileDeceleration = groundedByCollision ?
                        ActiveMovementProfile.groundDeceleration : ActiveMovementProfile.airDeceleration;

                    velocity.X = MathP.StepTowards(velocity.X, 0, profileDeceleration * frameTime);
                }

                //Ground-specific movement
                if (groundedByCollision)
                {
                    if (velocity.Y < -1)
                        velocity.Y = -1;

                    if (Raylib.IsKeyPressed(KeyboardKey.KEY_SPACE))
                    {
                        velocity.Y = jumpForce;
                        jumpedFromHeight = position.Y;
                    }

                    isCrouching = Raylib.IsKeyDown(KeyboardKey.KEY_S);
                }
                //Airborne-specific movement
                else
                {
                    float g = velocity.Y > 9 && Raylib.IsKeyDown(KeyboardKey.KEY_SPACE) ? gravity * jumpHeldGravityMod : gravity;

                    if (position.Y - GetJumpRise() > jumpedFromHeight || !(velocity.Y == jumpForce) || !Raylib.IsKeyDown(KeyboardKey.KEY_SPACE))
                    {
                        velocity.Y -= g * frameTime;
                    }

                    if (velocity.Y > 0 && Raylib.IsKeyReleased(KeyboardKey.KEY_SPACE))
                    {
                        velocity.Y *= jumpCancelStopper;
                    }

                    if (velocity.Y < -terminalVelocity) velocity.Y = -terminalVelocity;

                    if (isCrouching && Raylib.IsKeyUp(KeyboardKey.KEY_S) && velocity.Y < -12f) isCrouching = false;
                }

                position += velocity * frameTime;
                
                if (isCrouching)
                {
                    hitboxOffset.Y = -0.275f;
                    hitboxSize.Y = 0.8f;
                }
                else
                {
                    hitboxOffset.Y = 0;
                    hitboxSize.Y = 1.375f;
                }

                HandleCollision(frameTime, out bool colliding, out Vector2 escapeVector);
                if (colliding)
                {
                    //Bang head
                    if (escapeVector.Y < 0) velocity.Y = 0;

                    //Stop momentum on sides
                    if ((escapeVector.X < 0 && velocity.X > 0) || (escapeVector.X > 0 && velocity.X < 0)) velocity.X = 0;
                }
                groundedByCollision = colliding && escapeVector.Y > 0;

                //Console.WriteLine($"Velocity = {velocity}");
                //Console.WriteLine($"Position = {Rendering.WorldVector(position.X + spriteOffset.X, position.Y + spriteOffset.Y).RoundXY() + Vect.Down}");
            }

            //Reset
            if (Raylib.IsKeyPressed(KeyboardKey.KEY_R))
            {
                position = Gameplay.spawnpoint;
            }
        }

        private void MouseTeleport()
        {
            position = Screen.GetMouseWorldPosition(Gameplay.playerCamera);
        }

        public override void RunBehaviour()
        {
            //Editor behaviour
            if (EntryPoint.startupMode == EntryPoint.LaunchMode.Editor)
            {
                if (Raylib.IsKeyDown(KeyboardKey.KEY_RIGHT))
                    position += new Vector2(1, 0) * 5 * Clock.DeltaTime;
                if (Raylib.IsKeyDown(KeyboardKey.KEY_UP))
                    position += new Vector2(0, 1) * 5 * Clock.DeltaTime;
                if (Raylib.IsKeyDown(KeyboardKey.KEY_LEFT))
                    position += new Vector2(-1, 0) * 5 * Clock.DeltaTime;
                if (Raylib.IsKeyDown(KeyboardKey.KEY_DOWN))
                    position += new Vector2(0, -1) * 5 * Clock.DeltaTime;
                return;
            }

            if (Gameplay.debugEnabled && Raylib.IsMouseButtonPressed(MouseButton.MOUSE_MIDDLE_BUTTON))
                MouseTeleport();

            //Gather input
            Vector2 inputVector = Input.GetWASDInput();

            //Gameplay behaviour
            HandleMovement(inputVector, Gameplay.executedFrames);
            HandleCameraMovement();

            if (velocity.X > 0) facingRight = true;
            if (velocity.X < 0) facingRight = false;

            //Debug
            if (Gameplay.debugEnabled)
            {
                DebugText.WriteLate("Velocity X", Math.Round(velocity.X, 2).ToString());
                DebugText.WriteLate("Velocity Y", Math.Round(velocity.Y, 2).ToString());
                DebugText.WriteLate("H.Turning", hardTurning);
                DebugText.WriteLate("H.T.Speed", Math.Round(hardTurningSpeed, 2));
                DebugText.WriteLate("Jump Rise", Math.Round(GetJumpRise(), 2));
                DebugText.WriteLate("Is rising", !(position.Y - GetJumpRise() > jumpedFromHeight || !(velocity.Y == jumpForce)));
            }
        }

        //Initialisation
        public PlayerCharacter()
        {
            hitboxSize = new Vector2(0.875f, 1.375f);
            position = Vector2.Zero;
            spriteSheet.texture = Raylib.LoadTexture("..\\..\\..\\Assets\\playerSpriteSheet.png");
            spriteOffset = new Vector2(-0.5f, 0.825f);
        }
    }

    public struct MovementProfile
    {
        public float groundSpeed;
        public float groundAcceleration; //speed units per second
        public float groundDeceleration;
        public float groundHardTurn;

        public float airSpeed;
        public float airAcceleration;
        public float airDeceleration;
        public float airHardTurn;
    }
}