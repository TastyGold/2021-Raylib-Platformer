﻿using System;
using System.Collections.Generic;
using System.Numerics;
using System.Threading;
using Levels;
using Raylib_cs;
using MathExtras;
using Player;

namespace Engine
{
    public static partial class EditorPlus
    {
        //Configuration Options
        private const int targetFramerate = 240;
        private static Camera2D sceneCamera = new Camera2D
        {
            offset = new Vector2(Screen.screenWidth / 2, Screen.screenHeight / 2),
            target = new Vector2(Screen.screenWidth / 2, Screen.screenHeight / -2),
            zoom = 1,
        };
        private const float cameraSpeed = 600;
        private const float cameraZoomPower = 0.1f;
        private static Color skyboxColor = new Color(184, 204, 216, 255);
        private static Color outlineColor = new Color(80, 80, 80, 200);
        private static Color toolColor = new Color(80, 80, 80, 50);

        //Runtime Variables
        private static Vector2? mouseDownWorldPosition = null;
        private static Vector2? mouseLastWorldPosition = null;
        private static Vector2? cameraMousePanOrigin = null;
        private static object heldObject = null;
        private static bool drawingSemisolid = false;

        //Launch method
        public static async void Launch()
        {
            //Initialisation
            Raylib.InitWindow(Screen.screenWidth, Screen.screenHeight, "EditorPlus");
            Raylib.SetTargetFPS(targetFramerate);
            Raylib.SetExitKey(KeyboardKey.KEY_ESCAPE);

            Level editorLevel = await FileManager.ReadLevelFromFile(EntryPoint.levelPath);

            editorLevel.ActiveScene.AddEntity(
                new PlayerCharacter() {
                    scene = editorLevel.ActiveScene
                }, 
                new Vector2(10, 10));

            Tilemap activeTilemap = editorLevel.ActiveScene.mainTilemap;
            editorLevel.ActiveScene.RecalculateSemisolidOrdering();

            //Update loop
            while (!Raylib.WindowShouldClose())
            {
                //Diagnostics
                Rendering.ResetDrawCalls();

                //Gather input
                Vector2 mousePosition = GetMouseWorldPosition();

                //Editor Shortcuts
                if (Input.CtrlDown() && Raylib.IsKeyPressed(KeyboardKey.KEY_S))
                {
                    await FileManager.SaveLevelToFile(editorLevel, EntryPoint.levelPath);
                }

                //Camera movement
                HandleCameraMovement(mousePosition);

                //Start drawing
                Raylib.BeginDrawing();
                Raylib.ClearBackground(skyboxColor);
                Raylib.BeginMode2D(sceneCamera);

                //Run editor functionality
                RunToolBehaviour(mousePosition, ref activeTilemap, ref editorLevel);

                //Handle GUI logic
                HandleToolCycling();

                //Handle undo/redo
                if (Input.CtrlDown() && Raylib.IsKeyPressed(KeyboardKey.KEY_Z))
                {
                    editorLevel.sceneRef = editorLevel.ActiveScene;
                    ActionHistory.UndoLastAction(ref editorLevel.CurrentSceneReference());
                }
                if (Input.CtrlDown() && Raylib.IsKeyPressed(KeyboardKey.KEY_Y))
                {
                    editorLevel.sceneRef = editorLevel.ActiveScene;
                    ActionHistory.RedoNextAction(ref editorLevel.CurrentSceneReference());
                }

                //Render scene
                activeTilemap.DrawGrid(sceneCamera.zoom);
                editorLevel.DrawActiveScene();
                Raylib.EndMode2D();

                //Render GUI
                Raylib.DrawFPS(10, 10);
                Raylib.DrawText($"Draw calls: {Rendering.DrawCalls}", 10, 30, 20, Color.DARKGREEN);
                DrawToolText(10, 40);

                //End drawing
                Raylib.EndDrawing();

                //Next frame prep
                mouseLastWorldPosition = mousePosition;
            }

            //Termination
            Raylib.CloseWindow();
        }

        //Mouse position functions
        private static Vector2 GetMouseWorldPosition()
        {
            Vector2 mousePos = Raylib.GetMousePosition();
            mousePos.Y = Screen.screenHeight - mousePos.Y;

            float screenTilesX = Screen.screenWidth / Screen.iscalar / sceneCamera.zoom;
            float screenTilesY = Screen.screenHeight / Screen.iscalar / sceneCamera.zoom;

            mousePos.X /= Screen.screenWidth / screenTilesX;
            mousePos.Y /= Screen.screenHeight / screenTilesY;

            Vector2 tileOffset = (sceneCamera.target - sceneCamera.offset * new Vector2(1, -1) / sceneCamera.zoom) / Screen.iscalar * new Vector2(1, -1);
            mousePos += tileOffset;

            return mousePos;
        }
        private static Semisolid? GetSemisolidAtMouse(Level level, Vector2 mousePosition)
        {
            for (int i = level.ActiveScene.semisolids.Count; i > 0; i--)
            {
                Semisolid s = level.ActiveScene.SemisolidsDescending[i - 1];
                if (s.Overlaps(mousePosition.ToVector2Int()))
                {
                    mouseDownWorldPosition = mousePosition.Floor();
                    return s;
                }
            }
            return null;
        }

        //Handles camera movement
        private static void HandleCameraMovement(Vector2 mousePosition)
        {
            if (Raylib.IsMouseButtonPressed(MouseButton.MOUSE_MIDDLE_BUTTON))
            {
                cameraMousePanOrigin = mousePosition;
            }

            if (Raylib.IsMouseButtonReleased(MouseButton.MOUSE_MIDDLE_BUTTON))
            {
                cameraMousePanOrigin = null;
            }

            if (Raylib.IsMouseButtonDown(MouseButton.MOUSE_MIDDLE_BUTTON))
            {
                sceneCamera.target -= (mousePosition - (Vector2)cameraMousePanOrigin) * Vect.FlipY * Screen.iscalar;
            }
            else
            {
                Vector2 cameraMoveVector = Input.GetWASDInput() * Vect.FlipY;
                float cameraZoomInput = Input.GetMouseScroll();
                float speedMod = Raylib.IsKeyDown(KeyboardKey.KEY_LEFT_SHIFT) ? 1.75f : 1;
                speedMod /= sceneCamera.zoom;

                sceneCamera.target += cameraMoveVector * cameraSpeed * speedMod * Raylib.GetFrameTime();

                HandleCameraZooming(mousePosition);
            }
        }
        private static void HandleCameraZooming(Vector2 mousePosition)
        {
            float scroll = Input.GetMouseScroll();

            if (scroll > 0)
            {
                //Zoom in
                sceneCamera.zoom *= 1 + cameraZoomPower;
                sceneCamera.target = Vector2.Lerp(sceneCamera.target, Rendering.WorldVector(mousePosition), cameraZoomPower);
            }
            if (scroll < 0)
            {
                //Zoom out
                sceneCamera.zoom /= 1 + cameraZoomPower;
                sceneCamera.target = Vector2.Lerp(sceneCamera.target, Rendering.WorldVector(mousePosition), -cameraZoomPower);
            }
        }

        //Interface for objects that can be dragged in the editor
        public interface IDraggable
        {
            public void DragPosition(Vector2Int vector);
        }
    }
}