﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace Levels
{
    public static class FileManager
    {
        public const string levelDataPath = "..\\..\\..\\LevelData";

        /// <summary>
        /// Writes a level instance to a .lvl file
        /// </summary>
        /// <param name="level">Level instance to be saved to the file</param>
        /// <param name="path">The path relative to the LevelData folder. Eg: "TestLevel.lvl" or "LevelFolder\\TestLevel.lvl"</param>
        /// <returns></returns>
        public static async Task SaveLevelToFile(Level level, string path)
        {
            Console.WriteLine("");
            Console.WriteLine($"Saving level file: {path}");

            using (BinaryWriter outputFile = new BinaryWriter(File.Open(Path.Combine(levelDataPath, path), FileMode.Create)))
            {
                //Metadata - TBD

                //Scenes
                outputFile.Write(level.NumberOfScenes);
                Console.WriteLine($"Number of scenes: {level.NumberOfScenes}");

                for (int i = 0; i < level.NumberOfScenes; i++)
                {
                    //Tilemap
                    await outputFile.WriteTilemap(level.GetScene(i).mainTilemap);

                    //Semisolids
                    await outputFile.WriteSemisolids(level.GetScene(i).semisolids);
                }
            }

            Console.WriteLine($"Finished saving level to file {path}");
            Console.WriteLine("");
        }
        public static async Task<Level> ReadLevelFromFile(string path)
        {
            Console.WriteLine("");
            Console.WriteLine($"Reading level from file: {path}");

            if (!File.Exists(Path.Combine(levelDataPath, path)))
            {
                Console.WriteLine("Level does not exists, creating new");
                Console.WriteLine("");
                return Level.Empty;
            }

            Level levelData = new Level();

            using ( BinaryReader binaryFile = new BinaryReader(File.Open(Path.Combine(levelDataPath, path), FileMode.Open)))
            {
                //Metadata - TBD

                //Scenes
                int numberOfScenes = binaryFile.ReadByte();
                Console.WriteLine($"Number of scenes: {numberOfScenes}");

                for (int i = 0; i < numberOfScenes; i++)
                {
                    byte?[,] _mainTilemap = await binaryFile.ReadTilemap();
                    List<Semisolid> _semisolids = await binaryFile.ReadSemisolids();

                    levelData.AddScene(new Scene()
                    {
                        mainTilemap = new Tilemap(_mainTilemap),
                        semisolids = _semisolids
                    });
                }
            }

            Console.WriteLine($"Finished reading level: {path}");
            Console.WriteLine("");
            return levelData;
        }

        private static async Task WriteTilemap(this BinaryWriter outputFile, Tilemap map)
        {
            //Dimensions
            int xSize = map.GetTilemapWidth;
            int ySize = map.GetTilemapHeight;

            Console.WriteLine($"Writing tilemap. Size <{xSize}, {ySize}>");

            outputFile.Write((ushort)xSize);
            outputFile.Write((ushort)ySize);

            byte?[,] tiles = map.GetTilemapData();

            //Tiles
            for (int x = 0; x < xSize; x++)
            {
                for (int y = 0; y < ySize; y++)
                {
                    outputFile.Write(tiles[x, y].HasValue);
                }
            }
            for (int x = 0; x < xSize; x++)
            {
                for (int y = 0; y < ySize; y++)
                {
                    if (tiles[x, y].HasValue) outputFile.Write((byte)tiles[x, y]);
                }
            }

            Console.WriteLine("Finished writing tilemap");
        }
        private static async Task<byte?[,]> ReadTilemap(this BinaryReader binaryFile)
        {
            //Dimensions
            ushort xSize = binaryFile.ReadUInt16();
            ushort ySize = binaryFile.ReadUInt16();

            Console.WriteLine($"Reading tilemap. Size: <{xSize}, {ySize}>");

            //Tiles
            bool[,] nonAirTiles = new bool[xSize, ySize];

            for (int x = 0; x < xSize; x++)
            {
                for (int y = 0; y < ySize; y++)
                {
                    nonAirTiles[x, y] = binaryFile.ReadBoolean();
                }
            }

            byte?[,] tiles = new byte?[xSize, ySize];

            for (int x = 0; x < xSize; x++)
            {
                for (int y = 0; y < ySize; y++)
                {
                    tiles[x, y] = nonAirTiles[x, y] ? binaryFile.ReadByte() : (byte?)null;
                }
            }

            Console.WriteLine($"Finished reading tilemap");
            return tiles;
        }

        private static async Task WriteSemisolids(this BinaryWriter outputFile, List<Semisolid> semisolids)
        {
            Console.WriteLine($"Saving semisolids. Amount: {semisolids.Count}");

            //Amount
            outputFile.Write((ushort)semisolids.Count);

            for (int i = 0; i < semisolids.Count; i++)
            {
                //Write semisolid to file
                outputFile.Write((byte)semisolids[i].themeIndex);
                outputFile.Write((ushort)semisolids[i].x);
                outputFile.Write((ushort)semisolids[i].y);
                outputFile.Write((byte)semisolids[i].width);
                outputFile.Write((byte)semisolids[i].height);
                outputFile.Write((bool)semisolids[i].hasSurface);
            }

            Console.WriteLine("Finished saving semisolids");
        }
        private static async Task<List<Semisolid>> ReadSemisolids(this BinaryReader binaryFile)
        {
            Console.WriteLine("Reading semisolids");
            List<Semisolid> semisolids = new List<Semisolid>();

            //Amount
            ushort amount = binaryFile.ReadUInt16();

            for (int i = 0; i < amount; i++)
            {
                //Read semisolid
                byte themeIndex = binaryFile.ReadByte();
                ushort x = binaryFile.ReadUInt16();
                ushort y = binaryFile.ReadUInt16();
                byte width = binaryFile.ReadByte();
                byte height = binaryFile.ReadByte();
                bool hasSurface = binaryFile.ReadBoolean();

                semisolids.Add(new Semisolid(x, y, width, height, hasSurface, themeIndex));
            }

            Console.WriteLine($"Finished reading semisolids. Amount: {amount}");
            return semisolids;
        }
    }
}