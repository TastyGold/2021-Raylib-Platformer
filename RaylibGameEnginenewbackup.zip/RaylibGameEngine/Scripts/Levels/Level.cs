﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using System.Linq;
using Engine;
using Raylib_cs;
using MathExtras;

namespace Levels
{
    public class Level
    {
        //Scene control
        private List<Scene> scenes;
        private int activeSceneIndex = 0;
        public Scene ActiveScene => scenes.Count > 0 ? scenes[activeSceneIndex] : null;
        public byte NumberOfScenes => (byte)scenes.Count;
        
        public Scene sceneRef;
        public ref Scene CurrentSceneReference()
        {
            return ref sceneRef;
        }

        public Scene GetScene(int sceneIndex)
        {
            return scenes[sceneIndex];
        }

        public void DrawActiveScene()
        {
            ActiveScene.SemisolidsDescending.DrawAll();

            switch (EntryPoint.startupMode)
            {
                case EntryPoint.LaunchMode.Editor: //realtime tilemap
                    ActiveScene.mainTilemap.DrawAllTiles();
                    break;
                case EntryPoint.LaunchMode.Gameplay: //baked tilemap
                    Raylib.DrawTextureEx(ActiveScene.bakedTiles.texture, Vect.Down * ActiveScene.bakedTiles.texture.height * Screen.scalar, 0, 4, Color.WHITE);
                    Rendering.CountDrawCall();
                    break;
            }
            
            foreach (EntityManagement.Entity e in ActiveScene.GetEntityList)
            {
                e.Draw();
            }
        }

        public void AddScene(Scene newScene)
        {
            scenes.Add(newScene);
        }

        public void LoadScene(int scene)
        {
            if (scenes.Count < scene + 1)
            {
                throw new IndexOutOfRangeException($"Scene [{scene}] does not exist");
            }
        }

        public Level()
        {
            this.scenes = new List<Scene>();
        }
        public Level(List<Scene> scenes)
        {
            this.scenes = scenes;
        }
        public static Level Empty = new Level()
        {
            scenes = new List<Scene> { new Scene() }
        };
    }

    public class Scene
    {
        //World data
        public Tilemap mainTilemap;
        public List<Semisolid> semisolids = new List<Semisolid>();
        public List<Semisolid> SemisolidsDescending = new List<Semisolid>();
        public void RecalculateSemisolidOrdering()
        {
            if (semisolids.Count > 0)
            {
                SemisolidsDescending = semisolids.OrderByDescending(o => ((o.y + o.height - 1) * 256) + o.width).ToList();
            }
            else
            {
                SemisolidsDescending = new List<Semisolid>();
            }
        }
        public RenderTexture2D bakedTiles;
        public void BakeTilemapToTexture()
        {
            bakedTiles = mainTilemap.BakeTilemapTexture();
        }

        //Entity data
        public List<EntityManagement.Entity> GetEntityList { get; } = new List<EntityManagement.Entity>();

        public void AddEntity(EntityManagement.Entity newEntity, Vector2 position)
        {
            newEntity.position = position;
            UpdateEvent += newEntity.Update;
            GetEntityList.Add(newEntity);
        }

        //Behaviour
        public void Update()
        {
            UpdateEvent(this, EventArgs.Empty);
        }
        public event EventHandler UpdateEvent;
        protected virtual void OnUpdate(EventArgs e)
        {
            UpdateEvent?.Invoke(this, e);
        }

        //Initialisation
        public Scene()
        {
            mainTilemap = new Tilemap();
        }
    }
}