﻿using System;
using System.Collections.Generic;
using System.Numerics;
using MathExtras;
using Engine;
using Raylib_cs;

namespace Levels
{
    public struct Semisolid : EditorPlus.IDraggable
    {
        //Static const variables
        public const float colliderTrimming = 0.2f;
        public const float surfaceDepthLeniency = 0.2f;

        //Meta variables
        public byte themeIndex;
        public readonly SpriteSheet tileSheet;

        //Struct variables
        public int x;
        public int y;
        public int width;
        public int height;
        public bool hasSurface;

        public CullingRule culling;

        //Corner members
        public Vector2Int CornerA
        {
            get
            {
                return new Vector2Int(x, y);
            }
            set
            {
                if (value.X - x >= width || value.Y - y >= height)
                {
                    throw new ArgumentOutOfRangeException();
                }
                width -= (ushort)(value.X - x);
                height -= (ushort)(value.Y - y);
                x = (ushort)value.X;
                y = (ushort)value.Y;
            }
        }
        public Vector2Int CornerB
        {
            get
            {
                return new Vector2Int(x + width - 1, y + height - 1);
            }
            set
            {
                if (value.X - x <= 0 || value.Y <= 0)
                {
                    throw new ArgumentOutOfRangeException();
                }
                width = (ushort)(value.X - x);
                height = (ushort)(value.Y - y);
            }
        }
        public Vector2Int CornerC => new Vector2Int(x, y + height);
        public Vector2Int CornerD => new Vector2Int(x + width - 1, y);

        //Size and dimensions members
        public int StandingAreaWidth => width - (culling.left ? 0 : 1) - (culling.right ? 0 : 1);
        public int EquatorialAreaHeight => height - (culling.top ? 0 : 1) - (culling.bottom ? 0 : 1);
        public ushort SurfaceHeight => (ushort)(y + height - 1);
        public Rectangle GetRect() => new Rectangle(x, y, width, height);
        public bool Overlaps(Vector2Int coord)
        {
            return x <= coord.X && y <= coord.Y && coord.X < x + width && coord.Y < y + height;
        }

        //Rendering
        public void DrawSmart()
        {
            Vector2Int centerCornerA = CornerA + new Vector2Int(culling.left ? 0 : 1, culling.bottom ? 0 : 1);
            Vector2Int centerCornerB = CornerB - new Vector2Int(culling.right ? 0 : 1, culling.top ? 0 : 1);

            bool hasStandingArea = centerCornerA.X <= centerCornerB.X;
            bool hasEquatioralArea = centerCornerA.Y <= centerCornerB.Y;

            //Draw top
            if (!culling.top)
            {
                if (!culling.left)
                {
                    Raylib.DrawTexturePro(
                        tileSheet.texture,
                        tileSheet.GetSourceRec(0, hasSurface ? 1 : 0),
                        Rendering.GetScreenRect(x, CornerB.Y, 1, 1),
                        Rendering.SpriteRectOffset, 0, Color.WHITE
                        );
                    Rendering.CountDrawCall();
                }
                if (!culling.right)
                {
                    Raylib.DrawTexturePro(
                        tileSheet.texture,
                        tileSheet.GetSourceRec(2, hasSurface ? 1 : 0),
                        Rendering.GetScreenRect(CornerB.X, CornerB.Y, 1, 1),
                        Rendering.SpriteRectOffset, 0, Color.WHITE
                        );
                    Rendering.CountDrawCall();
                }
                if (hasStandingArea)
                {
                    Raylib.DrawTextureTiled(
                        tileSheet.texture,
                        tileSheet.GetSourceRec(1, hasSurface ? 1 : 0),
                        Rendering.GetScreenRect(centerCornerA.X, CornerB.Y, StandingAreaWidth, 1),
                        Rendering.SpriteRectOffset, 0, Screen.scalar, Color.WHITE
                        );
                    Rendering.CountDrawCall();
                }
            }

            //Draw equatorial layers
            if (hasEquatioralArea)
            {
                //Draw sides
                if (!culling.left)
                {
                    Raylib.DrawTextureTiled(
                        tileSheet.texture,
                        tileSheet.GetSourceRec(0, 2),
                        Rendering.GetScreenRect(x, centerCornerB.Y, 1, EquatorialAreaHeight),
                        Rendering.SpriteRectOffset, 0, Screen.scalar, Color.WHITE
                        );
                    Rendering.CountDrawCall();
                }
                if (!culling.right)
                {
                    Raylib.DrawTextureTiled(
                        tileSheet.texture,
                        tileSheet.GetSourceRec(2, 2),
                        Rendering.GetScreenRect(CornerB.X, centerCornerB.Y, 1, EquatorialAreaHeight),
                        Rendering.SpriteRectOffset, 0, Screen.scalar, Color.WHITE
                        );
                    Rendering.CountDrawCall();
                }

                //Draw center
                if (hasStandingArea)
                {
                    Raylib.DrawTextureTiled(
                        tileSheet.texture,
                        tileSheet.GetSourceRec(1, 2),
                        Rendering.GetScreenRect(centerCornerA.X, centerCornerB.Y, StandingAreaWidth, EquatorialAreaHeight),
                        Rendering.SpriteRectOffset, 0, Screen.scalar, Color.WHITE
                        );
                    Rendering.CountDrawCall();
                }
            }

            //Draw bottom
            if (!culling.bottom)
            {
                if (!culling.left)
                {
                    Raylib.DrawTexturePro(
                        tileSheet.texture,
                        tileSheet.GetSourceRec(0, 3),
                        Rendering.GetScreenRect(x, y, 1, 1),
                        Rendering.SpriteRectOffset, 0, Color.WHITE
                        );
                    Rendering.CountDrawCall();
                }
                if (!culling.right)
                {
                    Raylib.DrawTexturePro(
                        tileSheet.texture,
                        tileSheet.GetSourceRec(2, 3),
                        Rendering.GetScreenRect(CornerB.X, y, 1, 1),
                        Rendering.SpriteRectOffset, 0, Color.WHITE
                        );
                    Rendering.CountDrawCall();
                }
                if (hasStandingArea)
                {
                    Raylib.DrawTextureTiled(
                        tileSheet.texture,
                        tileSheet.GetSourceRec(1, 3),
                        Rendering.GetScreenRect(centerCornerA.X, y, StandingAreaWidth, 1),
                        Rendering.SpriteRectOffset, 0, Screen.scalar, Color.WHITE
                        );
                    Rendering.CountDrawCall();
                }
            }
        }

        //Transformation
        public void DragPosition(Vector2Int vector)
        {
            x += vector.X;
            y += vector.Y;
        }

        //Initialisation
        public Semisolid(int positionX, int positionY, int width, int height, bool hasSurface, byte themeIndex)
        {
            this.themeIndex = (byte)themeIndex;
            tileSheet = SpriteSheet.standardGrass;
            culling = new CullingRule(false, false, false, false);

            x = (ushort)positionX;
            this.width = (ushort)width;
            this.height = (ushort)height;
            this.hasSurface = hasSurface;
            y = (ushort)positionY;
        }
        public Semisolid(Vector2 CornerA, Vector2 CornerB, bool hasSurface, byte themeIndex)
        {
            Vectex v = new Vectex(CornerA, CornerB);

            v.min = v.min.Floor();
            v.max = v.max.Ceiling() + Vector2.One;

            this.themeIndex = themeIndex;
            tileSheet = SpriteSheet.standardGrass;
            culling = new CullingRule(false, false, false, false);

            x = (ushort)v.min.X;
            width = (ushort)v.max.X - (ushort)v.min.X;
            height = (ushort)v.max.Y - (ushort)v.min.Y;
            this.hasSurface = hasSurface;
            y = (ushort)v.min.Y;
        }

        //Culling rule struct for semisolid edges and corners
        public struct CullingRule
        {
            public bool top;
            public bool bottom;
            public bool left;
            public bool right;

            public bool All
            {
                get
                {
                    return top && bottom && left && right;
                }
                set
                {
                    top = value;
                    bottom = value;
                    left = value;
                    right = value;
                }
            }

            public CullingRule(bool top, bool bottom, bool left, bool right)
            {
                this.top = top;
                this.bottom = bottom;
                this.left = left;
                this.right = right;
            }
        }
    }

    public static class SemisolidFunc
    {
        public static void DrawAll(this List<Semisolid> ss)
        {
            foreach (Semisolid s in ss)
            {
                s.DrawSmart();
            }
        }

        public static List<Semisolid> GetSemisolidOverlaps(this List<Semisolid> ss, Vectex area)
        {
            List<Semisolid> ns = new List<Semisolid>();

            foreach (Semisolid s in ss)
            {
                if (s.x + s.width > area.min.X && s.x < area.max.X)
                    if (s.y + s.height > area.min.Y && s.y < area.max.Y)
                    {
                        ns.Add(s);
                    }
            }

            return ns;
        }
    }
}