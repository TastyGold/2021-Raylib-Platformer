﻿using Raylib_cs;
using System.Numerics;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Engine;
using MathExtras;
using System.Diagnostics;

namespace Levels
{
    public class Tilemap
    {
        //Tileset
        private readonly Texture2D tileset = Raylib.LoadTexture("..\\..\\..\\Assets\\Tilesets\\grassTiles.png");
        private readonly int tileWidth = 12;
        private readonly int tileHeight = 4;
        private readonly Tiling.Format tilesetFormat = Tiling.Tileset12x4;
        private Vector2 GetTileRec(int index)
        {
            int x = index % tileWidth;
            int y = (index - x) / tileWidth;

            return new Vector2(x, y);
        }
        public Rectangle GetTilesetSourceRec(int index)
        {
            int tileX = index % tileWidth;
            int tileY = (index - tileX) / tileWidth;

            return new Rectangle(tileX * 16, tileY * 16, 16, 16);
        }

        //Tilemap
        private readonly byte?[,] tilemap = new byte?[512, 128];
        public byte?[,] GetTilemapData()
        {
            return tilemap;
        }
        public byte? GetTileData(int x, int y)
        {
            if (x < 0 || y < 0 || x >= GetTilemapWidth || y >= GetTilemapHeight)
            {
                return null;
            }
            return tilemap[x, y];
        }
        public byte? GetTileData(Vector2 pos)
        {
            int x = (int)pos.X;
            int y = (int)pos.Y;
            return GetTileData(x, y);
        }
        public byte?[] GetTileColumn(int column)
        {
            byte?[] output = new byte?[tilemap.GetLength(1)];

            for (int y = 0; y < tilemap.GetLength(1); y++)
            {
                output[y] = tilemap[column, y];
            }

            return output;
        }

        public int GetTilemapWidth => tilemap.GetLength(0);
        public int GetTilemapHeight => tilemap.GetLength(1);

        public bool OverlapRec(float ax, float ay, float bx, float by)
        {
            if (ax > bx || ay > by)
            {
                throw new ArgumentException($"A must have values smaller than B: A = <{ax}, {ay}>, B = <{bx}, {by}>");
            }

            Vector2Int a = new Vector2Int((int)Math.Max(ax, 0), (int)Math.Max(ay, 0));
            Vector2Int b = new Vector2Int((int)Math.Min(bx, GetTilemapWidth - 1), (int)Math.Min(by, GetTilemapHeight - 1));

            for (int x = a.X; x <= b.X; x++)
            {
                for (int y = a.Y; y <= b.Y; y++)
                {
                    if (tilemap[x, y].HasValue)
                    {
                        return true;
                    }
                }
            }

            return false;
        }
        public bool OverlapRec(Vectex v)
        {
            return OverlapRec(v.min.X, v.min.Y, v.max.X, v.min.Y);
        }
        public bool OverlapHitbox(Vector2 position, Vector2 hitboxSize)
        {
            return OverlapRec(position.X - (hitboxSize.X / 2), position.Y - (hitboxSize.X / 2), position.X + (hitboxSize.X / 2), position.Y + (hitboxSize.X / 2));
        }

        //Tilemap manipulation
        public void SetTile(int x, int y, byte? id = 13)
        {
            if (x >= 0 && x < GetTilemapWidth && y >= 0 && y < GetTilemapHeight)
            tilemap[x, y] = id;
        }
        public void SetTile(Vector2 coords, byte? id = 13)
        {
            SetTile((int)coords.X, (int)coords.Y, id);
        }
        public void SetTilesRec(int ax, int ay, int bx, int by, byte? id = 13)
        {
            int startX = Math.Min(ax, bx);
            int startY = Math.Min(ay, by);
            int endX = Math.Max(ax, bx);
            int endY = Math.Max(ay, by);

            for (int x = startX; x <= endX; x++)
            {
                for (int y = startY; y <= endY; y++)
                {
                    SetTile(x, y, id);
                }
            }
        }
        public void SetTilesRec(Vector2 startPos, Vector2 endPos, byte? id = 13)
        {
            SetTilesRec((int)startPos.X, (int)startPos.Y, (int)endPos.X, (int)endPos.Y, id);
        }
        public void FormatTilesRec(int ax, int ay, int bx, int by)
        {
            int startX = Math.Min(ax, bx);
            int startY = Math.Min(ay, by);
            int endX = Math.Max(ax, bx);
            int endY = Math.Max(ay, by);

            startX = startX < 0 ? 0 : startX;
            startY = startY < 0 ? 0 : startY;
            endX = endX >= GetTilemapWidth ? GetTilemapWidth - 1 : endX;
            endY = endY >= GetTilemapHeight ? GetTilemapHeight - 1: endY;

            for (int x = startX; x <= endX; x++)
            {
                for (int y = startY; y <= endY; y++)
                {
                    if ((x >= 0 && y >=0) && tilemap[x, y].HasValue)
                    {
                        byte? tileIndex = null;
                        string code = Tiling.GetTilingCode(tilemap, x, y);
                        for (byte ry = 0; ry < tileHeight; ry++)
                        {
                            for (byte rx = 0; rx < tileWidth; rx++)
                            {
                                if (tilesetFormat.rules[rx, ry].CompareCode(code))
                                {
                                    tileIndex = (byte)((ry * tileWidth) + rx);
                                    ry = (byte)tileHeight;
                                    rx = (byte)tileWidth;
                                }
                            }
                        }
                        if (tileIndex != null)
                        {
                            tilemap[x, y] = tileIndex;
                        }
                        else
                        {
                            throw new Exception($"Failed to format tile at <{x}, {y}> " +
                                $"\nAttempted formatting code = {code}");
                        }
                    }
                }
            }
        }
        public void FormatTilesRec(Vector2 startPos, Vector2 endPos)
        {
            FormatTilesRec((int)startPos.X, (int)startPos.Y, (int)endPos.X, (int)endPos.Y);
        }

        //Rendering
        public void DrawTile(int index, int x, int y)
        {
            Raylib.DrawTexturePro(
                tileset,
                GetTilesetSourceRec(index),
                Rendering.GetScreenRect(new Rectangle(x, y, 1, 1)),
                new Vector2(0, 0),
                0f,
                Color.WHITE
                );
            Rendering.CountDrawCall();
        }
        public void DrawTilesRec(int startX, int startY, int endX, int endY)
        {
            for (int x = startX; x <= endX; x++)
            {
                for (int y = startY; y <= endY; y++)
                {
                    if (tilemap[x, y].HasValue)
                    {
                        int u = Screen.iscalar;
                        Raylib.DrawTexturePro(
                            tileset,
                            GetTilesetSourceRec((byte)tilemap[x, y]),
                            new Rectangle(x * u, (-y - 1) * u, u, u),
                            new Vector2(0, 0),
                            0f,
                            Color.WHITE
                            );
                        Rendering.CountDrawCall();
                    }
                }
            }
        }
        public void DrawAllTiles()
        {
            for (int x = 0; x < GetTilemapWidth; x++)
            {
                for (int y = 0; y < GetTilemapHeight; y++)
                {
                    if (tilemap[x, y].HasValue)
                    {
                        int u = Screen.iscalar;
                        Raylib.DrawTexturePro(
                            tileset,
                            GetTilesetSourceRec((byte)tilemap[x, y]),
                            new Rectangle(x * u, (-y - 1) * u, u, u),
                            new Vector2(0, 0),
                            0f,
                            Color.WHITE
                            );
                        Rendering.CountDrawCall();
                    }
                }
            }
        }

        public RenderTexture2D BakeTilemapTexture()
        {
            Stopwatch t = new Stopwatch();
            t.Start();

            RenderTexture2D tex = Raylib.LoadRenderTexture(GetTilemapWidth * 16, GetTilemapHeight * 16);
            Raylib.BeginTextureMode(tex);
            for (int x = 0; x < GetTilemapWidth; x++)
            {
                for (int y = 0; y < GetTilemapHeight; y++)
                {
                    if (tilemap[x, y].HasValue)
                    {
                        Rectangle srec = GetTilesetSourceRec((byte)tilemap[x, y]);
                        srec.height *= -1;

                        Raylib.DrawTextureRec(
                            tileset,
                            srec,
                            new Vector2(x*16, y*16),
                            Color.WHITE
                            );
                    }
                }
            }
            Raylib.EndTextureMode();

            Console.WriteLine("Tilemap texture baked: " + t.ElapsedMilliseconds + "ms");
            return tex;
        }

        private const float gridZoomOutPoint = 0.2f;
        private const int largeGridScaleAmount = 8;
        private Color gridColor = new Color(100, 100, 100, 100);
        public void DrawGrid(float cameraZoom)
        {
            int s = (int)Screen.iscalar;
            int increment = cameraZoom > gridZoomOutPoint ? 1 : largeGridScaleAmount;

            for (int x = 0; x <= GetTilemapWidth; x += increment)
            {
                Raylib.DrawLine(x * s, 0, x * s, -GetTilemapHeight * s, gridColor);
                Rendering.CountDrawCall();
            }
            for (int y = 0; y <= GetTilemapHeight; y += increment)
            {
                Raylib.DrawLine(0, -y * s, GetTilemapWidth * s, -y * s, gridColor);
                Rendering.CountDrawCall();
            }
        }
        public void DrawGrid(int increment, Color gridColor)
        {
            int s = (int)Screen.iscalar;

            for (int x = 0; x <= GetTilemapWidth; x += increment)
            {
                Raylib.DrawLine(x * s, 0, x * s, -GetTilemapHeight * s, gridColor);
                Rendering.CountDrawCall();
            }
            for (int y = 0; y <= GetTilemapHeight; y += increment)
            {
                Raylib.DrawLine(0, -y * s, GetTilemapWidth * s, -y * s, gridColor);
                Rendering.CountDrawCall();
            }
        }

        //Initialisation
        public Tilemap()
        {

        }
        public Tilemap(byte?[,] map)
        {
            tilemap = map;
        }
    }
}