﻿using System;
using System.Numerics;
using Raylib_cs;
using MathExtras;

namespace Engine
{
    public static class Screen
    {
        public const int screenWidth = 1600;
        public const int screenHeight = 900;
        public const int unitPixelSize = 4;
        public const int pixelScale = 16;
        public const float scalar = pixelScale / unitPixelSize;
        public const int iscalar = unitPixelSize * pixelScale;

        public static Vector2 GetMouseWorldPosition(this Camera2D cam)
        {
            Vector2 mousePos = Raylib.GetMousePosition();
            mousePos.Y = screenHeight - mousePos.Y;
            mousePos -= cam.offset;

            Vector2 pos = cam.target / iscalar * Vect.FlipY;
            pos += mousePos / iscalar / cam.zoom;

            return pos;
        }
    }
}