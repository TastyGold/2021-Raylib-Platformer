﻿using Raylib_cs;
using System.Numerics;
using MathExtras;
namespace Engine
{
    public static class Rendering
    {
        private static int drawCalls = 0;
        public static void ResetDrawCalls() => drawCalls = 0;
        public static void CountDrawCall(int amount = 1) => drawCalls += amount;
        public static int DrawCalls => drawCalls;

        [System.Obsolete("Use Clock.DeltaTime instead.")]
        public static float GetFrameTime()
        {
            return Raylib.GetFrameTime();
        }

        public static Rectangle GetScreenRect(Rectangle rect)
        {
            int u = Screen.iscalar;
            return new Rectangle(rect.x * u, (-rect.y) * u, rect.width * u, rect.height * u);
        }
        public static Rectangle GetScreenRect(float x, float y, float width, float height)
        {
            int u = Screen.iscalar;
            return new Rectangle(x * u, (-y) * u, width * u, height * u);
        }

        public static Vector2 WorldVector(Vector2 position)
        {
            return position * Screen.iscalar * new Vector2(1, -1);
        }
        public static Vector2 WorldVector(float x, float y)
        {
            return new Vector2(x, -y) * (Screen.pixelScale * Screen.unitPixelSize);
        }

        public static void DrawRectangleVx(Vectex vx)
        {
            int s = Screen.unitPixelSize / Screen.pixelScale;
            Raylib.DrawRectangle((int)(s*vx.min.X), (int)(s * -vx.max.Y), (int)(s*(vx.max.X - vx.min.X)), (int)(s*(vx.max.Y - vx.min.Y)), Color.WHITE);
            Rendering.CountDrawCall();
        }

        public static Vector2 SpriteRectOffset => Vect.Up * Screen.iscalar;
    }
}